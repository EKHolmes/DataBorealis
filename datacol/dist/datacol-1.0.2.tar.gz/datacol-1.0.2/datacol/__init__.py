# __init__.py

# Version of the DataCol package
__version__ = "1.0.2"
