DataCol: An extremely lightweight, localized database module. 
Visit the github (https://github.com/EKHolmes/DataCol) for more information.

